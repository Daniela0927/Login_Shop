export default function Users() {
  return (
    <div className="min-h-screen p-8 bg-gray-50">
      <h1 className="text-2xl font-semibold mb-4">Usuarios</h1>
      <div className="bg-white p-4 rounded shadow">Lista de usuarios (demo)</div>
    </div>
  )
}
